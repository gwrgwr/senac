<?php

include "conexao.php";

if(isset($_POST['login'])){
    $login = trim($_POST['login']);
    $senha = trim($_POST['senha']);
    $nome = trim($_POST['nome']);
    $sobrenome = trim($_POST['sobrenome']);
    $nivel = trim($_POST['nivel']);
    $foto = trim($_POST['foto']);

    $sql = "insert into usuario(login,senha,nome,sobrenome,nivel,foto) values ('$login','$senha','$nome','$sobrenome','$nivel','$foto')";
    $incluir = mysqli_query($conexao,$sql);

    if($incluir){
        echo 
        "<script>

        alert('Usuário cadastro com sucesso!');
        window.location = 'listarAluno.php';
        </script>";
     } else {
        echo "
        <p> Sistema temporariamente fora do ar. Tente novamente mais tarde. </p>.
        <p> Entre em contato com o administrador do Sistema. </p>";
        echo mysqli_error($conexao);
    } 
}
else {
    echo "
    <p> Esta é uma página de tratamento de dados. </p>
    <p> Clique <a href='formularioUsuario.php'> aqui </a> para incluir um aluno.";
    }

                

