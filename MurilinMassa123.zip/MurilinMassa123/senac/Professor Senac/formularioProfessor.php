<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Professores</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>



   <div class="container bg-danger pag">
    
     <div class="text-end">
     <a target="_blank" href="listarProfessor.php"><button type="button" class="btn btn-sm btn-success">Ver lista de professores</button></a>
     </div>
        <h1>Cadastro de Professores</h1>
        <form name="form" method="post" action="incluirProfessor.php">
  <div class="mb-3">
    <label for="nome" class="form-label">Nome</label>
    <input type="text" class="form-control" id="nome" name="nome" required>
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" name="email"  placeholder="nome@exemplo.com" required>
  </div>
  <div class="mb-3">
    <label for="telefone" class="form-label">Telefone</label>
    <input type="text" class="form-control" id="telefone" maxlength="14" name="telefone" required>
  </div>
  <div class="mb-3">
    <label for="cargahoraria" class="form-label">Carga horária</label>
    <input type="text" class="form-control" id="cargahoraria"  name="cargahoraria" required>
  </div>
  <button  type="submit" class="btn btn-primary">Enviar Formulário</button>
</div>
  
  





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>