<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
  form{
      text-align:center
  }
    p{
        text-align:center
    }
    body{
        background-image:  url('Lolzin.png')
    }
</style>
<body>
    <form name="form" method="post" action ="#">
    <input type="text" name="num" required>
    <input type="submit" value="Verificar">
    </form>
    <?php
    
    
    
    
    //entrada
    if(isset($_POST['num'])){

        $num= $_POST['num'];


        //processamento
        ($num %2 ==0)?($sit= "Par"):($sit = "Ímpar");



        //saída
        echo "<p>$num é $sit</p>";
        
    }
    else{
        echo  "<p> Digite um número qualquer e clique em verificar</p>";
    }
   
    




    ?>
</body>
</html>