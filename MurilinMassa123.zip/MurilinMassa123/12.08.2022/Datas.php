<?php
date_default_timezone_set('America/Sao_Paulo');
echo "<b>Hoje é </b>";
echo date ("D, d/M");
echo "<b> e são </b>";
echo date ("H:i:s");
echo "<hr>";

echo date_default_timezone_get();
echo " - ";
echo date ("H:i:s");


echo "<hr>";
date_default_timezone_set ('Europe/Amsterdam');
echo date_default_timezone_get();
echo " - ";
echo date ("H:i:s");


echo "<hr>";
date_default_timezone_set ('America/Detroit');
echo date_default_timezone_get();
echo " - ";
echo date ("H:i:s");

echo "<hr>";
date_default_timezone_set ('Asia/Tokyo');
echo date_default_timezone_get();
echo " - ";
echo date ("H:i:s");

echo "<hr>";
date_default_timezone_set ('Asia/Dubai');
echo date_default_timezone_get();
echo " - ";
echo date ("H:i:s");

echo "<hr>";
date_default_timezone_set ('Australia/Sydney');
echo date_default_timezone_get();
echo " - ";
echo date ("H:i:s");

/*
Função date
D- dia da semana
d - dia do mês
m - mês em números
M - Mês por extenso
y - ano com 2 digitos
Y - ano cm 4 digitos

h - 12 horas
H - 24 horas
i - minutos 
s - segundos
a - aa/pm
*/


?>