<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e.e</title>
</head>
<body>
    <?php

    // ==

    if(3 == 2) {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    echo "<br/>";
    
    // ===

    if(2 === "2") {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    echo "<br/>";
    
    // != ou <>

    if("x" != "y") {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    echo "<br/>";
    
    // !==

    if(5 !== "5") {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    echo "<br/>";
    
    // <

    if(2 < 18) {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    echo "<br/>";
    
    // >

    if(2 > 18) {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    echo "<br/>";
    
    // <=

    if(2 <= 2) {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }
    
    echo "<br/>";

    // >=

    if(4 >= 4) {
        echo "Verdadeiro";

    } else {
        echo "Falso";

    }


                    