<?php

    echo "
        <h2 style='text-align: center'> Funções para Strings (Textos) </h2>
        <hr>
    ";

    $nome = "Seu Nome Completo";

    echo "
        <b> Normal: </b> $nome <br>
    ";

    echo "
        <b> Maiúsculo:</b> strtoupper($nome) <br>
    ";
    
    echo "<b> Maiúsculo> </b> " . strtoupper($nome) . "<hr>";

    echo "<b> Normal: </b>";
    echo $nome;
    echo "<br>";

    echo "<b> Maiúsculo: </b>";
    echo strtoupper($nome);
    echo "<br>";

    echo "<b> Minúsculo: </b>";
    echo strtolower($nome);
    echo "<br>";

    echo "<b> Invertido: </b>";
    echo strrev($nome);
    echo "<br>";

    echo "<b> Quantidade de Dígitos: </b>";
    echo strlen($nome);
    echo "<br>";

    echo "<b> Troca de Caracteres: </b>";
    echo strtr($nome,"o","_");
    echo "<br>";
    
    //substr(variavel,posição inicial, quantidade de dígitos)
    echo "<b> Partes do Texto: </b>";
    echo substr($nome,9,8);
    echo "<br>";

    echo "<b> Separando textos: </b>";
    $partes = explode(" ",$nome);
    $tot = count($partes)-1;
    echo "$partes[0] $partes[$tot]";
    echo "<br>";

    echo "<b> Remove espaços a Esquerda: </b>";
    echo ltrim($nome);
    echo "<br>";

    echo "<b> Remove espaços a Direta: </b>";
    echo rtrim($nome);
    echo "<br>";

    echo "<b> Remove espaços a Esquerda e a Direita: </b>";
    echo trim($nome);
    echo "<br>";
