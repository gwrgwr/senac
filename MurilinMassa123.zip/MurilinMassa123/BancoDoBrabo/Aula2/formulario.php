<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <h2>par ou impar</h2>
    <form class="mb-3 form-check" name="form" method="post" action="#"> 
        <input type="text" name="num" required> 
        <input class="btn btn-primary" type="submit" value="verificar">     
    </form>
   
    <?php
       if(isset($_POST['num'])){ //Se nao tiver sido postado um valor setado nao roda, se tiver um valor postado retorna
       //Entrada
        $num = $_POST['num'];

        //processamento
        ($num % 2 == 0)?($sit = "par") :($sit = "impar"); //Faz a operaçao e se o resto for igual a 0 é par se nao for igual é impar

        //saída
        echo "$num é $sit";
       }
       else{
           echo"Digite um numero qualquer e clique em verificar";
       }
       

    ?>
      <a href="formulario.html"></a>  <input type="submit" value="verificar"> 
    

</body>
</html>