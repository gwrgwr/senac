<?php
   echo"<h1 style= 'color:red; text-align: center'>Minha Primeira Pagina </h1>";
   echo"<hr>";
   echo"
        <p>Isto é muito facil<p>
        <p>PHP <p>
        <p> <p>
        
        
   
   
   ";

   //Entrada
   $a = 15 ;
   $b = 6;
   
   //Processamento
   $soma = $a + $b;

   //Saida
   echo "$a + $b = $soma <hr>";

   //Processamento
    $subtracao = $a - $b;

   //Saida
   echo "$a - $b = $subtracao<hr>";

   //Processamento
   $divisao = $a/$b;

   //Saida
   echo "$a/$b = $divisao<hr>";
  
   //Processamento
   $multiplicacao = $a * $b;

   //Saida
   echo "$a * $b = $multiplicacao<hr>";
  
   //Processamento
   $modulo = $a % $b;

   //Saida
   echo "$a % $b = $modulo<hr>";

    /*o uso das aspas simples não reconhece o valor das variaveis as aspas
    simples imprime na tela o seu conteúdo na integra, reconhecendo apenas html e css.
    */

?>