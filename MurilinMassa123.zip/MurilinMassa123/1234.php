<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e.e</title>
</head>
<body>
    <?php    
    echo "Igual (==) - Veirifica se os valores comparados são <b>iguais</b><br/>";
    echo "Idêntico (===) - Verifica se os valores comparados são <b>iguais e do mesmo tipo</b><br/>";
    echo "Diferente (!=) - Verifica se os valores comparados são <b>diferentes</b><br/>";
    echo "Diferente (<>) - Verifica se os valores comparados são <b>diferentes</b><br/>";
    echo "Não idêntico (!==) - Verifica se os valores comparados são <b>diferentes e de tipos diferentes</b><br/>";
    echo "Menor (<) - Verifica se o valor da esquerda é <b>menor</b> que o valor da direita<br/>";
    echo "Maior (>) - Verifica se o valor da esquerda é <b>maior</b> que o valor da direita<br/>";
    echo "Menor igual (<=) - Verifica se o valor da esquerda é <b>menor ou igual</b> ao valor da direita<br/>";
    echo "Maior igual (>=) - Verifica se o valro da esquerda é <b>maior ou igual</b> ao valor da direita<br/>";
    










    ?>
</body>
</html>